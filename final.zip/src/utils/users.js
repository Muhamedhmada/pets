export const users = [
    {
        "__type": "ENTIDAD.EUsuario",
        "ID": 0,
        "ID_ENCRIP": "0hv3AGsZXj8=",
        "EMAIL": "bigbang",
        "PASSWORD": "18CB5657CA8C78F9552B1C1C184D07F4",
        "NOMBRE": "Big Bang",
        "APELLIDO": "Company",
        "FOTO": "2DFB5F187120B3DB4F0AD2AED22FD2E9.jpg",
        "EXTENSION": null,
        "SEXO": "Masculino",
        "TELEFONO": null,
        "CELULAR": null,
        "FECHA_NAC": null,
        "PERFIL_ID": 1,
        "ACTIVO": 1,
        "ESTADO": 0,
        "TOKEN_ACTIVACION": null,
        "TOKEN_PASSWORD": null,
        "USUARIO_PERFIL": {
            "ID": 1,
            "PERFIL": "ADMINISTRADOR"
        },
        "EVENTOS": null,
        "CARRITO": null
    }
]